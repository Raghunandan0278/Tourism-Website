$(document).ready(function() {

    // owl-carousel blog
    $('.owl-carousel').owlCarousel({
        loop:true,
        autoplay:true,
        autoplayTimeout:3000,
        dots:true
    });

    
});